package com.example.spawswelcome

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.*
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.UnderlineSpan
import android.view.View
import android.widget.*
import com.google.firebase.auth.FirebaseAuth

class Login : AppCompatActivity() {
    private lateinit var acctv: TextView
    private lateinit var imageView: ImageView
    private lateinit var tvHeading: TextView
    private lateinit var loginEmail: EditText
    private lateinit var loginPassword: EditText
    private lateinit var loginBtn: Button
    private lateinit var checkShowPassword1: CheckBox
    private lateinit var forgotPassword: TextView
    private lateinit var mAuth: FirebaseAuth

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        acctv = findViewById(R.id.acctv)
        imageView = findViewById(R.id.imageView)
        tvHeading = findViewById(R.id.tvHeading)
        loginEmail = findViewById(R.id.loginEmail)
        loginPassword = findViewById(R.id.loginPassword)
        loginBtn = findViewById(R.id.loginBtn)
        checkShowPassword1 = findViewById(R.id.checkShowPassword1)
        forgotPassword = findViewById(R.id.forgotPassword)
        mAuth = FirebaseAuth.getInstance()
        loginBtn.setOnClickListener(View.OnClickListener { view -> // method call
            loginUser(view)
            //log(view)
        })
        forgotPassword.setOnClickListener(View.OnClickListener { view ->
            forgot(view)
        })
        checkShowPassword1.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                loginPassword.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                //    confirmPassword.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            } else {
                loginPassword.inputType =
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                //  confirmPassword.inputType =
                //       InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            // Move cursor to the end of the text
            loginPassword.setSelection(loginPassword.text.length)
            //  confirmPassword.setSelection(confirmPassword.text.length)
        }



        val text = "Don\'t have an account? Sign Up"
        val spannableString = SpannableString(text)

        // Find the start and end index of "Log in"
        val startIndex = text.indexOf("Sign Up")
        val endIndex = startIndex + "Sign Up".length

        // Apply UnderlineSpan to "Log in"
        spannableString.setSpan(UnderlineSpan(), startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

        // Apply ForegroundColorSpan to "Log in" (make it black)
        spannableString.setSpan(ForegroundColorSpan(resources.getColor(android.R.color.white)), startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

        // Apply ClickableSpan to "Log in"
        val clickableSpan = object : ClickableSpan() {
            override fun onClick(widget: View) {
                // Handle click action, e.g., navigate to the login screen
                val intent = Intent(this@Login, Register::class.java)
                startActivity(intent)
            }
        }
        spannableString.setSpan(clickableSpan, startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

        // Make the TextView clickable and handle links
        acctv.movementMethod = LinkMovementMethod.getInstance()

        // Apply the SpannableString to the TextView
        acctv.text = spannableString




        // Function to update the button's enabled state
        fun updateButtonState() {
            val allFieldsFilled =
                loginEmail.text.isNotEmpty() &&
                        loginPassword.text.isNotEmpty()
            loginBtn.isEnabled = allFieldsFilled
        }

        // Set up listeners for the text fields
        loginEmail.addTextChangedListener(createTextWatcher({ updateButtonState() }))
        loginPassword.addTextChangedListener(createTextWatcher({ updateButtonState() }))


    }
    private fun loginUser(view: View?) {
        try {
            val email = loginEmail.text.toString().trim()
            val password = loginPassword.text.toString().trim()
            if (TextUtils.isEmpty(email)) {
                Toast.makeText(this, "Please enter an email address!", Toast.LENGTH_SHORT).show()
                loginEmail.requestFocus()
                return
            }
            if (TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Please enter a password!", Toast.LENGTH_SHORT).show()
                loginPassword.requestFocus()
                return
            }
            mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@Login, HomePage::class.java)
                    startActivity(intent)
                    loginEmail.setText("")
                    loginPassword.setText("")
                    loginEmail.requestFocus()

                } else {
                    Toast.makeText(this, "Login Unsuccessful! Please try again.", Toast.LENGTH_SHORT).show()
                    loginEmail.setText("")
                    loginPassword.setText("")
                    loginEmail.requestFocus()
                }
            }
        } catch (eer: Exception) {
            Toast.makeText(this, "Error Occurred: " + eer.message, Toast.LENGTH_SHORT).show()
        }
    }
    private fun log(view: View?) {
        val intent = Intent(this@Login, HomePage::class.java)
        startActivity(intent)
        finish()
    }
    private fun forgot(view: View){
        val intent = Intent(this@Login, HomePage::class.java)
        startActivity(intent)
        finish()
    }
    private fun createTextWatcher(callback: () -> Unit): TextWatcher {
        return object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                callback.invoke()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        }
    }
}