package com.example.spawswelcome

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.widget.*
import com.google.firebase.auth.FirebaseAuth

class Register : AppCompatActivity() {
    private lateinit var regBtn: Button
    private lateinit var imgReg: ImageView
    private lateinit var tvReg: TextView
    private lateinit var regEmail: EditText
    private lateinit var regPassword: EditText
    private lateinit var confirmPassword: EditText
    private lateinit var checkShowPassword: CheckBox
    private lateinit var mAuth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        regBtn = findViewById(R.id.regBtn)
        imgReg = findViewById(R.id.imgReg)
        tvReg = findViewById(R.id.tvReg)
        regEmail = findViewById(R.id.regEmail)
        regPassword = findViewById(R.id.regPassword)
        confirmPassword = findViewById(R.id.confirmPassword)
        checkShowPassword = findViewById(R.id.checkShowPassword)
        mAuth = FirebaseAuth.getInstance()

        checkShowPassword.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                regPassword.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                //    confirmPassword.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            } else {
                regPassword.inputType =
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                //  confirmPassword.inputType =
                //       InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            // Move cursor to the end of the text
            regPassword.setSelection(regPassword.text.length)
            //  confirmPassword.setSelection(confirmPassword.text.length)
        }

        // Function to update the button's enabled state
        fun updateButtonState() {
            val allFieldsFilled =
                        regEmail.text.isNotEmpty() &&
                        regPassword.text.isNotEmpty() &&
                        confirmPassword.text.isNotEmpty()

            regBtn.isEnabled = allFieldsFilled
        }

        // Set up listeners for the text fields
        regEmail.addTextChangedListener(createTextWatcher({ updateButtonState() }))
        regPassword.addTextChangedListener(createTextWatcher({ updateButtonState() }))
        confirmPassword.addTextChangedListener(createTextWatcher({ updateButtonState() }))
        regBtn.setOnClickListener{
            registerUser()
        }
    }

    private fun registerUser() {
        try {
            val email = regEmail.text.toString().trim()
            val password = regPassword.text.toString().trim()
            val confirmPassword = confirmPassword.text.toString().trim()

            if (TextUtils.isEmpty(email) ){
                Toast.makeText(this, "Please enter an email address!", Toast.LENGTH_SHORT).show()
                return
            }else
                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(this, "Please enter a password!", Toast.LENGTH_SHORT).show()
                    return
                } else
                    if (TextUtils.isEmpty(confirmPassword) && password != confirmPassword) {
                        Toast.makeText(this, "Blank or not same as password", Toast.LENGTH_SHORT).show()
                        return
                    }
            mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Registration Successful!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@Register, Login::class.java)
                    startActivity(intent)
                } else{
                    Toast.makeText(this, "Registration Unsuccessful! Please try again.", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (eer: Exception) {
            Toast.makeText(this, "Error Occurred: " + eer.message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun createTextWatcher(callback: () -> Unit): TextWatcher {
        return object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                callback.invoke()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        }
    }
}
