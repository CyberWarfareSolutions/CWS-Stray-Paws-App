package com.example.spawswelcome

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.UnderlineSpan
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var textview: TextView
    private lateinit var textview2: TextView
    private lateinit var haveAccTextView: TextView
    private lateinit var createAccount: Button
    private val textToAnimate = "Message Placed Here"
    private var currentIndex = 0

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textview = findViewById(R.id.orTextView)
        textview2 = findViewById(R.id.textView2)
        haveAccTextView = findViewById(R.id.haveAcc)
        createAccount = findViewById(R.id.createAcc)
        createAccount.setOnClickListener(View.OnClickListener { view -> // method call
            create(view)
        })


        startAnimation()

        val text = "Already have an account? Log in"
        val spannableString = SpannableString(text)

        // Find the start and end index of "Log in"
        val startIndex = text.indexOf("Log in")
        val endIndex = startIndex + "Log in".length

        // Apply UnderlineSpan to "Log in"
        spannableString.setSpan(UnderlineSpan(), startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

        // Apply ForegroundColorSpan to "Log in" (make it black)
        spannableString.setSpan(ForegroundColorSpan(resources.getColor(android.R.color.white)), startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

        // Apply ClickableSpan to "Log in"
        val clickableSpan = object : ClickableSpan() {
            override fun onClick(widget: View) {
                // Handle click action, e.g., navigate to the login screen
                val intent = Intent(this@MainActivity, Login::class.java)
                startActivity(intent)
            }
        }
        spannableString.setSpan(clickableSpan, startIndex, endIndex, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

        // Make the TextView clickable and handle links
        haveAccTextView.movementMethod = LinkMovementMethod.getInstance()

        // Apply the SpannableString to the TextView
        haveAccTextView.text = spannableString
    }



    private fun startAnimation() {
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            if (currentIndex < textToAnimate.length) {
                textview2.text = textToAnimate.substring(0, currentIndex + 1)
                currentIndex++
                startAnimation()
            }
        }, 100) // Delay in milliseconds
    }
    private fun create(view: View?) {
        val intent = Intent(this@MainActivity, Register::class.java)
        startActivity(intent)
        finish()
    }

}